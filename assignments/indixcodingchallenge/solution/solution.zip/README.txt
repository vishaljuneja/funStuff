compile:
javac ProductMatcher





run:
java ProductMatcher




Input: 
Mobiles-Infibeam.txt
Mobiles-Master-Data.txt



Output:
Output.xls